from django.apps import AppConfig


class TaskAppConfig(AppConfig):
    name = 'task_app'
